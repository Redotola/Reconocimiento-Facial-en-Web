CREATE TABLE IF NOT EXISTS tip_usu (
  id_tip_usu int(11) NOT NULL,
  nom_tip_usu varchar(20) NOT NULL,
  PRIMARY KEY (id_tip_usu)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO tip_usu (id_tip_usu, nom_tip_usu) VALUES
(1, 'Administrador'),
(2, 'Empleado'),
(3, 'Recursos humanos');


create table horario(
  id_hora int AUTO_INCREMENT,
  nombre varchar (15),
  PRIMARY KEY(id_hora)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

insert into horario (id_hora,nombre) values (1,'Nocturno'), (2,'Matutino'), (3,'Vespertino');


DROP TABLE users;
CREATE TABLE IF NOT EXISTS users (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(20) NOT NULL,
  email varchar(100) NOT NULL,
  password varchar(100) NOT NULL,
  id_tip_usu int(11) NOT NULL,
  id_hora int not null,
  PRIMARY KEY (id),
  KEY id_tip_usu (id_tip_usu),
  Foreign Key (id_hora) REFERENCES horario(id_hora)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
COMMIT;
insert into users (name,email,password,id_tip_usu,id_hora) VALUES ('Axl','axl@gmail.com','lol',1,1);
insert into users (name,email,password,id_tip_usu,id_hora) VALUES ('Lalo','lalo@gmail.com','lol',3,3);
insert into users (name,email,password,id_tip_usu,id_hora) VALUES ('Antunez','antunez@gmail.com','lol',2,2);


create table asistencia(

  id int PRIMARY KEY AUTO_INCREMENT,
  hora TIME not null,
  id_empleado int not null,
  Foreign Key (id_empleado) REFERENCES users(id)

)ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

create trigger asistencias before insert on asistencia
for each row
    BEGIN
    set new.hora=TIME(NOW());
end;

SELECT * FROM horario;

CREATE TABLE justificantes(
id int PRIMARY KEY not null AUTO_INCREMENT,
empcorreo varchar(100),
fecha date not null,
motivo varchar(200) not null,
id_emp int not null,
Foreign Key (empcorreo) REFERENCES users(email),
Foreign Key (id_emp) REFERENCES users(id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

select * from justificantes;
select *from users;