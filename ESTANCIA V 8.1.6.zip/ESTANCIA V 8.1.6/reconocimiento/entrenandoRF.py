import cv2
import os
import numpy as np

def entrenar(name):
    dataPath='C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data'
    peopleList=os.listdir(dataPath)
    print ("Lista de personas: ", peopleList)

    labels=[]
    faceData=[]
    label=0

    for nameDir in peopleList:
        personPath=dataPath+'/'+nameDir
        print("Leyendo imagenes")
        
        for fileName in os.listdir(personPath):
            print("Rostros: ", nameDir+'/'+fileName)
            labels.append(label)
            faceData.append(cv2.imread(personPath+'/'+fileName,0))
            image=cv2.imread(personPath+'/'+fileName,0)
            cv2.imshow('image', image)
            cv2.waitKey(10)
        label+=1

    face_recognizer=cv2.face.EigenFaceRecognizer_create()

    print("Entrenando")
    face_recognizer.train(faceData,np.array(labels))
    path='modelo'+name+'.xml'
    face_recognizer.write(path)
    
name='Antunez'
entrenar(name)