import cv2
import os

def facial(name):
    dataPath="C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data"
    imagePath=(os.listdir(dataPath))
    print("imagePath=", imagePath)

    face_recognizer=cv2.face.EigenFaceRecognizer_create()


    face_recognizer.read('modelo'+name+'.xml')

    cap=cv2.VideoCapture(0,cv2.CAP_DSHOW)
    faceclas=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count=0
    while True:
        red, frame=cap.read()
        if red==False: break
        gray=cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        auxFrame=gray.copy()

        faces=faceclas.detectMultiScale(gray, 1.3,5)

        for (x,y,w,h) in faces:
            rostro=auxFrame[y:y+h, x:x+w]
            rostro=cv2.resize(rostro,(150,150), interpolation=cv2.INTER_CUBIC)
            result=face_recognizer.predict(rostro)
            cv2.putText(frame, '{}'.format(result),(x,y-5), 1, 1.3, (255,255,0), 1, cv2.LINE_AA)
            if result[1]<4000:
                cv2.putText(frame, '{}'.format(imagePath[result[0]]),(x,y-25), 2, 1.1, (0,255,0), 1, cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w, y+h), (0,255,0),2)
                count+=1
            else:
                cv2.putText(frame,'Desconocido',(x,y-20), 2, 0.8, (0,0,255), 1, cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w, y+h), (0,255,0),2)
        cv2.imshow('frame', frame)
        k=cv2.waitKey(1)
        if k==27 or count==40:
            break
    cap.release()
    cv2.destroyAllWindows()
    

if __name__==('__main__'):
    err=1
    while(err==1):
        try:
            name=str(input("Inserta el nombre del usuario"))
            facial(name)
            err=0
        except Exception as e:
            print(f"Ocurrio un error de entrada de tipo : {e}")
            err=1
        