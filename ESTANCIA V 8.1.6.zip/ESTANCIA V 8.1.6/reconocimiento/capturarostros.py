import cv2
import os
import imutils

def captura(name):
    personName=name
    dataPath='C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data'
    personpath=dataPath+ '/' + personName
    print(personpath)

    if not os.path.exists(personpath):
        print("Carpeta creada: ", personpath)
        os.makedirs(personpath)
    else:
        return 1

    #captura de video estatico
    #cap=cv2.VideoCapture("Mel.mp4")

    #captura de video dinamico
    cap=cv2.VideoCapture(0,cv2.CAP_DSHOW)
    
    faceClassif=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count=0

    while True:
        ret, frame=cap.read()
        if ret==False:break
        frame = imutils.resize(frame, width=640)
        gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxframe=frame.copy()

        faces=faceClassif.detectMultiScale(gray, 1.3, 5)

        for (x,y,w,h) in faces:
            cv2.rectangle(frame,(x,y), (x+w,y+h), (0,255,0),2)
            rostro=auxframe[y:y+h,x:x+w]
            rostro=cv2.resize(rostro,(150,150), interpolation=cv2.INTER_CUBIC)
            cv2.imwrite(personpath+'/rostro_{}.jpg'.format(count),rostro)
            count+=1
        cv2.imshow('frame', frame)
        #k=cv2.waitKey(1)
        if count>=80:
            break

    cap.release()
    cv2.destroyAllWindows()
    return 0
    """k==27"""
    
name='Antunez'
captura(name)