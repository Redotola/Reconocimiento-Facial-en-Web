from flask import Flask,  render_template, request, redirect, url_for, session,flash # pip install Flask
from flask_mysqldb import MySQL # pip install Flask-MySQLdb
from notifypy import Notify
from reconocimiento import capturarostros, entrenandoRF, reconocimientofacial
#librerias de la prueba
import cv2
import os
import imutils
import numpy as np

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'test'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)
name=''

#SESION#
app.secret_key = "mysecretkey"
#ruta cuando inicia el programa mandamos a la direccion de login
@app.route('/')
def home():
    return render_template("login.html")    
#funcion que redirecciona a menu del administrador
@app.route('/menu')
def menu():
    return render_template('homeAdministrador.html')
#funcion que redirecciona a menu del director de recursos humanos
@app.route('/menu_Recu')
def menu_Recu():
    return render_template('homeRecursosHumanos.html')
#funcion que redirecciona a menu del empleado
@app.route('/menu_Empe')
def menu_Empe():
    return render_template('homeEmpleado.html')

#funcion que redirige a la pestaña login y realiza las validaciones
@app.route('/login', methods= ["GET", "POST"])
def login():
    try:
        notificacion = Notify()

        if request.method == 'POST':#si el metodo es POST realiza la obtencion del formulario los datos del usuario
            email = request.form['email']
            password = request.form['password']

            cur = mysql.connection.cursor()#abre un nuevo cursor para realizar operaciones en sql
            cur.execute("SELECT * FROM users WHERE email=%s",(email,))
            user = cur.fetchone()
            cur.close()

            if len(user)>0:
                if password == user["password"]:
                    session['name'] = user['name']
                    session['email'] = user['email']
                    session['tipo'] = user['id_tip_usu']
                    session['hora'] = user['id_hora']

                    if session['tipo'] == 1:
                        name=session['name']
                        return render_template("homeAdministrador.html")
                    elif session['tipo'] == 2:
                        name=session['name']
                        return render_template("homeEmpleado.html")
                    elif session['tipo'] == 3:
                        name=session['name']
                        return render_template("homeRecursosHumanos.html")
                else:
                    notificacion.title = "Error de Acceso"
                    notificacion.message="Correo o contraseña no valida"
                    notificacion.send()
                    return render_template("login.html")
            else:
                notificacion.title = "Error de Acceso"
                notificacion.message="No existe el usuario"
                notificacion.send()
                return render_template("login.html")
        else:
            return render_template("login.html")
    except Exception as e:
        notificacion.title="Error de sistema"
        notificacion.message=f"Error de tipo {e}"
        notificacion.send()
        flash("Error de acceso: {e}")
        return render_template("login.html")

##REGISTRA EMPLEADOS-ADMINISTRADOR    
@app.route('/registro', methods = ["GET", "POST"])

def registro():#funcion de registro de usuarios

    cur = mysql.connection.cursor()#creamos un cursor para operaciones sql
    cur.execute("SELECT * FROM tip_usu")
    tipo = cur.fetchall()
    cur.close()
    
    cur = mysql.connection.cursor()#creamos un cursor para operaciones sql
    cur.execute("SELECT * FROM horario")
    hora = cur.fetchall()
    cur.close()
    cont=0
    
    if request.method == 'GET':#si el metodo es GET renderizamos la plantilla y mandamos los datos
        return render_template("registro.html", tipo = tipo, hora = hora ) 
    else:
        #obtenemos del formulario los datos por medio de la supervariable GET
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        tip = request.form['tipo']
        hor = request.form['hora']

        cur=mysql.connection.cursor()#obtengo los correos de los usuarios
        cur.execute("Select email from users")#consultamos en la base de datos los usuarios
        val=cur.fetchall()#obtenemos todos los resultados de la consulta
        cur.close()#cerramos el cursor
        
        """
        for i in val:
            if email!=i:#diferente ==
                cont=cont+1
                pass
            else:#encontro uno igual
                pass
         """
        """ 
        if cont==0:
        """
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (name, email, password, id_tip_usu,id_hora) VALUES (%s,%s,%s,%s,%s)", (name, email, password,tip,hor))
        mysql.connection.commit()
        flash("Registro Exitoso")
        return redirect(url_for("registro"))
        """
        flash("Registro repetido")    
        return redirect(url_for('registro'))
        """



@app.route('/login')
def logout():
    return redirect(url_for('login'))


#### EDITAR REGISTROS EMPLEADOS-ADMINISTRADOR
@app.route('/editar')
def redirect_update():
    redirect('/editar')
    return render_template('editar.html')

@app.route('/editar', methods=['GET','POST'])
def update():
    if request.method == 'POST' or request.method=='GET':
        redirect('/editar')
        email = request.form['email']
        username=request.form['username']
        password = request.form['password']
        tipo = request.form['tipo']
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET name = %s,password = %s,id_tip_usu=%s where email=%s', (username, password, tipo, email))
        query='Select * from users'
        cur.execute(query)
        d=cur.fetchall()
        mysql.connection.commit()
        flash('USUARIO EDITADO SATISFACTORIAMENTE')
        return render_template('editar.html', data=d)
    else:
        return render_template('err404.html')

### MOSTRAR REGISTROS EMPLEADOS-ADMINISTRADOR
@app.route('/mostrar')
def mostrar():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users")
    d = cur.fetchall()
    return render_template('editar.html', data=d)

#### ELIMINAR REGISTROS EMPLEADOS-ADMINISTRADOR
@app.route('/delete/<string:id>')
def delete_usuario(id):
    cur = mysql.connection.cursor()
    cur.execute('DELETE FROM users WHERE id = {0}'. format(id))
    mysql.connection.commit()
    flash('USUARIO ELIMANDO SATISFACTORIAMENTE')
    return redirect(url_for("mostrar"))

##REGISTRA EMPLEADOS-RECURSOS HUMANOS    
@app.route('/registro_Recu', methods = ["GET", "POST"])

def registro_Recu():
    
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM horario")
    hora = cur.fetchall()
    cur.close()
    notificacion = Notify()
    
    if request.method == 'GET':
        return render_template("registro_Recu.html", hora = hora ) 

    else:
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hor = request.form['hora']

      
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (name, email, password, id_tip_usu,id_hora) VALUES (%s,%s,%s,%s,%s)", (name, email, password,2,hor))
        mysql.connection.commit()   
        flash("Registro Exitoso")
        notificacion.message="USUARIO YA REGISTRADO."
        notificacion.send()
        return redirect(url_for('registro_Recu'))


#### EDITAR REGISTROS EMPLEADOS-RECURSOS HUMANOS
@app.route('/editar_Recu')
def redirect_update_Recu():
    redirect('/editar_Recu')
    return render_template('editar_Recu.html')

@app.route('/editar_Recu', methods=['GET','POST'])
def update_Recu():
    if request.method == 'POST' or request.method=='GET':
        redirect('/editar_Recu')
        email = request.form['email']
        username=request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET name = %s,password = %s,id_tip_usu=%s where email=%s', (username, password, 2, email))
        query='Select * from users where id_tip_usu=2'
        cur.execute(query)
        d=cur.fetchall()
        mysql.connection.commit()
        flash('USUARIO EDITADO SATISFACTORIAMENTE')
        return render_template('editar_Recu.html', data=d)
    else:
        return render_template('err404.html')

### MOSTRAR REGISTROS EMPLEADOS-RECURSOS HUMANOS
@app.route('/mostrar_Recu')
def mostrar_Recu():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users where id_tip_usu=2")
    d = cur.fetchall()
    return render_template('editar_Recu.html', data=d)

#### ELIMINAR REGISTROS EMPLEADOS-ADMINISTRADOR 
@app.route('/delete_Recu/<string:id>')
def delete_usuario_Recu(id):
    cur = mysql.connection.cursor()
    cur.execute('DELETE FROM users WHERE id = {0}'. format(id))
    mysql.connection.commit()
    flash('USUARIO ELIMANDO SATISFACTORIAMENTE')
    return redirect(url_for('mostrar_Recu'))

    
### REGISTRO EMPLEADO-JUSTIFICANTE
#Redireccionamiento
@app.route('/emple_justificante')
def emple_justificante():
    return render_template('registro_Emple_Justificante.html')

#Entrando en la funcion para mostrar los justificantes
@app.route('/mostrar_justificante')
def mostrar_emple_Justificante():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users where id_tip_usu=2")
    d = cur.fetchall()
    return render_template('editar_Emple_Justificante.html', data=d)

#funcion para subir una justificacion
@app.route('/subir_justificante', methods=['GET','POST'])
def subir_justificante():
    try:
        app.logger.warning(f"Entrada a la funcion")
        ids=''
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM justificantes")
        d=cur.fetchall()
        cur.close()
        
        if request.method == 'GET':
            return render_template("registro_Emple_Justificante.html",data=d) 
        else:
            correo = request.form['correo']
            fecha = request.form['fecha']
            mensaje = request.form['mensaje']
            
            curl=mysql.connection.cursor()
            curl.execute('Select id from users where email=%s', (correo,))
            ids=curl.fetchone()
            if ids!='':
                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO justificantes (empcorreo,fecha,motivo,id_emp) VALUES (%s,%s,%s,%s)", (correo,fecha,mensaje,ids,))
                mysql.connection.commit()   
                mensaje='Exito al enviar el justificante'
                flash(mensaje)
                return render_template("registro_Emple_Justificante.html",data=d) 
            else:
                flash('Registro de justificante no valido o no existe el usuario')
                return render_template("registro_Emple_Justificante.html",data=d) 
    except Exception as e:
        flash(f"Error de sistema en justificante {e}")
        return redirect(url_for("subir_justificante"))


#Visualizar asistencias del empleado por medio del reconocimiento facial
@app.route("/visualizar_asistencias")
def asistencias():
    try:
        curl=mysql.connection.cursor()
        curl.execute("Select id from users where name=%s", (name,))
        ids=curl
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM asistencia where id_empleado=%s", (ids,))
        a = cur.fetchall()
        return render_template("asistencias.html", asistencias=a)
    except Exception as e:
        flash(f"Error de tipo {e} en pagina web")
        return render_template("asistencias.html", asistencias=a)
    
#Pase de lista por medio del reconocimiento facial
@app.route('/pase_asistencia_emp')
def asistencia():
    try:
        if((captura(name))==1):#devuelve 1 si ya existia el usuario por lo tanto solo lo reconocera
            facial(name)
            flash("Se ha realizado el pase de asistencia con exito")
        else:
            entrenar(name)#en caso contrario devolvera cero es decir que no se tiene registro del empleado
            facial(name)
        cur=mysql.connection.cursor()#se realiza la busqueda del id del usuario por medio del nombre en registro
        cur.execute("select id from users where name='%s'", (name,))
        ids=cur.fetchone()
        cur.execute("insert into asistencia (id_empleado) values (%s)", (ids,))#se obtiene y se envia en insercion de la asistencia
        mensaje="Se logro insertar el rostro del empleado"
        flash(mensaje)
        return render_template(url_for("/visualizar_asistencias"))
    except Exception as e:
        error=f'El reconocimiento ha fallado debido a un error de libreria {e}'
        flash(error)
        app.logger.warning(f"Error de tipo {e}")
        return redirect(url_for("asistencias"))


#prueba de forma local para revision de funciones
def captura(name):
    personName=name
    dataPath='C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data'
    personpath=dataPath+ '/' + personName
    print(personpath)

    if not os.path.exists(personpath):
        print("Carpeta creada: ", personpath)
        os.makedirs(personpath)
    else:
        return 1

    #captura de video estatico
    #cap=cv2.VideoCapture("Mel.mp4")

    #captura de video dinamico
    cap=cv2.VideoCapture(0,cv2.CAP_DSHOW)


    faceClassif=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count=0

    while True:
        ret, frame=cap.read()
        if ret==False:break
        frame = imutils.resize(frame, width=640)
        gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxframe=frame.copy()

        faces=faceClassif.detectMultiScale(gray, 1.3, 5)

        for (x,y,w,h) in faces:
            cv2.rectangle(frame,(x,y), (x+w,y+h), (0,255,0),2)
            rostro=auxframe[y:y+h,x:x+w]
            rostro=cv2.resize(rostro,(150,150), interpolation=cv2.INTER_CUBIC)
            cv2.imwrite(personpath+'/rostro_{}.jpg'.format(count),rostro)
            count+=1
        cv2.imshow('frame', frame)
        #k=cv2.waitKey(1)
        if count>=80:
            break

    cap.release()
    cv2.destroyAllWindows()
    return 0
    """k==27"""
    

def entrenar(name):
    dataPath='C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data'
    peopleList=os.listdir(dataPath)
    print ("Lista de personas: ", peopleList)

    labels=[]
    faceData=[]
    label=0

    for nameDir in peopleList:
        personPath=dataPath+'/'+nameDir
        print("Leyendo imagenes")
        
        for fileName in os.listdir(personPath):
            print("Rostros: ", nameDir+'/'+fileName)
            labels.append(label)
            faceData.append(cv2.imread(personPath+'/'+fileName,0))
            image=cv2.imread(personPath+'/'+fileName,0)
            cv2.imshow('image', image)
            cv2.waitKey(10)
        label+=1

    face_recognizer=cv2.face.EigenFaceRecognizer_create()

    print("Entrenando")
    face_recognizer.train(faceData,np.array(labels))
    path='modelo'+name+'.xml'
    face_recognizer.write(path)
    
def facial(name):
    dataPath="C:/Users/AXL/Desktop/ESTANCIA V 8.1.6/reconocimiento/Data"
    imagePath=(os.listdir(dataPath))
    print("imagePath=", imagePath)

    face_recognizer=cv2.face.EigenFaceRecognizer_create()


    face_recognizer.read('modelo'+name+'.xml')

    cap=cv2.VideoCapture(0,cv2.CAP_DSHOW)
    faceclas=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count=0
    while True:
        red, frame=cap.read()
        if red==False: break
        gray=cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        auxFrame=gray.copy()

        faces=faceclas.detectMultiScale(gray, 1.3,5)

        for (x,y,w,h) in faces:
            rostro=auxFrame[y:y+h, x:x+w]
            rostro=cv2.resize(rostro,(150,150), interpolation=cv2.INTER_CUBIC)
            result=face_recognizer.predict(rostro)
            cv2.putText(frame, '{}'.format(result),(x,y-5), 1, 1.3, (255,255,0), 1, cv2.LINE_AA)
            if result[1]<4000:
                cv2.putText(frame, '{}'.format(imagePath[result[0]]),(x,y-25), 2, 1.1, (0,255,0), 1, cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w, y+h), (0,255,0),2)
                count+=1
            else:
                cv2.putText(frame,'Desconocido',(x,y-20), 2, 0.8, (0,0,255), 1, cv2.LINE_AA)
                cv2.rectangle(frame, (x,y),(x+w, y+h), (0,255,0),2)
        cv2.imshow('frame', frame)
        k=cv2.waitKey(1)
        if k==27 or count==40:
            break
    cap.release()
    cv2.destroyAllWindows()
        
if __name__ == '__main__':
    app.run(port = 5000, debug=True)